<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-14 04:07:51
  from 'D:\ugm\xampp\htdocs\web11\templates\tpl\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e460f07638382_52229661',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '21513e477f78934044095f04c0b449faee957147' => 
    array (
      0 => 'D:\\ugm\\xampp\\htdocs\\web11\\templates\\tpl\\footer.tpl',
      1 => 1581649663,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e460f07638382_52229661 (Smarty_Internal_Template $_smarty_tpl) {
?>
  <!-- Footer -->
  <footer class="bg-light py-5">
    <div class="container">
      <div class="small text-center text-muted">Copyright &copy; 2019 - Start Bootstrap</div>
    </div>
  </footer><?php }
}
