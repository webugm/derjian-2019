<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-14 06:41:45
  from 'D:\ugm\xampp\htdocs\web11\templates\tpl\ok.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e463319d72eb5_66257984',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1642aa916cfcd3d1794861586332c8254e05ba32' => 
    array (
      0 => 'D:\\ugm\\xampp\\htdocs\\web11\\templates\\tpl\\ok.tpl',
      1 => 1581658859,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e463319d72eb5_66257984 (Smarty_Internal_Template $_smarty_tpl) {
?>
    <div class="container mt-5">
        <div class="jumbotron text-center">
            <h1 class="display-4">點餐成功</h1>
            <p class="lead">老闆馬上親自來確認，點餐內容及製作餐點</p>
            <hr class="my-4">
            <p>育將電腦工作室 mail：tawan158@gmail.com TEL：0921-560421</p>
            <a class="btn btn-primary btn-block" href="index.html" role="button">點餐</a>
            <a class="btn btn-success btn-block" href="https://www.ugm.com.tw" target="_blank" >官網</a>
        </div>

    </div><?php }
}
